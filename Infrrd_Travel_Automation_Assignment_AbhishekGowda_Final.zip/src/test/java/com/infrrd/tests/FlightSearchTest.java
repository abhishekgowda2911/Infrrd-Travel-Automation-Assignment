package com.infrrd.tests;

import com.infrrd.pages.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class FlightSearchTest {

    WebDriver driver;
    HomePage homePage;
    FlightsPage flightsPage;
    ResultsPage resultsPage;

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.makemytrip.com/");
    }

    @Test
    public void testFlightSearch() throws InterruptedException {
        homePage = new HomePage(driver);
        flightsPage = new FlightsPage(driver);

        // Navigate to Flights
        homePage.goToFlights();
        Thread.sleep(2000);

        // Enter cities
        flightsPage.enterFrom("Bangalore");
        Thread.sleep(1000);
        flightsPage.enterTo("Delhi");
        Thread.sleep(1500);

        // Select next month date
        flightsPage.selectNextMonthDate();
        Thread.sleep(1000);

        // Search
        flightsPage.clickSearch();

        // Wait for results to load
        Thread.sleep(8000);

        resultsPage = new ResultsPage(driver);
        resultsPage.printCheapestFlights();

        // Extra scenario: apply one-stop filter and print count
        resultsPage.applyOneStopFilterAndPrintCount();

        // Open Google in a new tab
        resultsPage.openNewTab("https://www.google.com");
        System.out.println("🆕 Opened Google in a new browser tab successfully!");
    }

    @AfterClass
    public void tearDown() {
        if(driver != null) driver.quit();
    }
}
