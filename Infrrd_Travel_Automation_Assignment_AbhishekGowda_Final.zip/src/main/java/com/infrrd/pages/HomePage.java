package com.infrrd.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

public class HomePage extends BasePage {

    private By flightsTab = By.xpath("//a[contains(@href,'flights') or contains(text(),'Flights')]"); // flexible

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public void goToFlights() {
        try {
            // some sites have overlays; using JS click if normal click fails
            WebElement el = driver.findElement(flightsTab);
            ((JavascriptExecutor)driver).executeScript("arguments[0].click();", el);
        } catch (Exception e) {
            driver.findElement(flightsTab).click();
        }
    }
}
