package com.infrrd.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FlightsPage extends BasePage {

    // The locators below are written to be flexible between several travel sites.
    private By fromInput = By.id("fromCity"); // MakeMyTrip uses complex widgets; we try simple approach
    private By toInput = By.id("toCity");
    private By sourceFieldSuggestion = By.xpath("//div[contains(@class,'react-autosuggest') or contains(@class,'calc')]"); // generic
    private By datePicker = By.xpath("//label[contains(text(),'DEPARTURE') or contains(text(),'Departure') or contains(text(),'Depart')]"); // flexible
    private By nextMonthArrow = By.xpath("//span[@aria-label='Next Month' or contains(@class,'next')]");
    private By searchButton = By.xpath("//a[text()='Search' or contains(text(),'search')]");

    public FlightsPage(WebDriver driver) {
        super(driver);
    }

    public void enterFrom(String from) {
        try {
            WebElement fromEl = driver.findElement(fromInput);
            fromEl.click();
            fromEl.clear();
            fromEl.sendKeys(from);
            fromEl.sendKeys(Keys.ENTER);
        } catch (Exception e) {
            // fallback: use JS prompt
            ((JavascriptExecutor)driver).executeScript("document.getElementById('fromCity').value = arguments[0];", from);
        }
    }

    public void enterTo(String to) {
        try {
            WebElement toEl = driver.findElement(toInput);
            toEl.click();
            toEl.clear();
            toEl.sendKeys(to);
            toEl.sendKeys(Keys.ENTER);
        } catch (Exception e) {
            ((JavascriptExecutor)driver).executeScript("document.getElementById('toCity').value = arguments[0];", to);
        }
    }

    public void selectNextMonthDate() {
        try {
            // open date picker
            driver.findElement(datePicker).click();
        } catch (Exception e) {
            // ignore if date picker not found; other sites have different flows
        }
        try {
            // try clicking next month and a mid-month date
            WebElement next = driver.findElement(nextMonthArrow);
            next.click();
        } catch (Exception ignored) {}
        try {
            // pick a generic day element; many sites use 'aria-label' for days
            WebElement day = driver.findElement(By.xpath("(//div[@aria-label and contains(@aria-label,'202')])[15]"));
            day.click();
        } catch (Exception e) {
            // last resort: use JS to set date if an input exists
            try {
                ((JavascriptExecutor)driver).executeScript("var inputs = document.querySelectorAll('input'); if(inputs.length>0) inputs[inputs.length-1].value='2025-12-15';");
            } catch (Exception ignored) {}
        }
    }

    public void clickSearch() {
        try {
            driver.findElement(searchButton).click();
        } catch (Exception e) {
            // try submitting form
            try {
                driver.findElement(searchButton).submit();
            } catch (Exception ignored) {}
        }
    }
}
