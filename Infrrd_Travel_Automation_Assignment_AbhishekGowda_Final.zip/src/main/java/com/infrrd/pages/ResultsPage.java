package com.infrrd.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.*;

public class ResultsPage extends BasePage {

    // Generic locators - these may require minor updates per site, but work for common patterns
    private By flightCards = By.xpath("//div[contains(@class,'listingCard') or contains(@class,'flightCard') or contains(@class,'resultRow')]"); 
    private By priceLabel = By.xpath(".//p[contains(@class,'actual-price') or contains(@class,'price') or contains(@class,'fare')]"); 
    private By oneStopFilter = By.xpath("//label[contains(.,'1 Stop') or contains(.,'Non Stop') or contains(.,'Stop')]"); // flexible

    public ResultsPage(WebDriver driver) {
        super(driver);
    }

    public void printCheapestFlights() {
        List<WebElement> flights = driver.findElements(flightCards);
        Map<Integer, String> flightMap = new HashMap<>();

        for (WebElement flight : flights) {
            try {
                String details = flight.getText();
                WebElement priceEl = flight.findElement(priceLabel);
                String priceText = priceEl.getText().replaceAll("[^0-9]", "");
                if(priceText.isEmpty()) continue;
                int price = Integer.parseInt(priceText);
                flightMap.put(price, details);
            } catch (Exception ignored) {}
        }

        List<Integer> prices = new ArrayList<>(flightMap.keySet());
        Collections.sort(prices);
        if (prices.size() >= 2) {
            System.out.println("\n✅ Cheapest Flight:\n" + flightMap.get(prices.get(0)));
            System.out.println("\n✅ Second Cheapest Flight:\n" + flightMap.get(prices.get(1)));
        } else if (prices.size() == 1) {
            System.out.println("\n✅ Only one flight found:\n" + flightMap.get(prices.get(0)));
        } else {
            System.out.println("⚠️ No flights found with the current locators. You can update ResultsPage locators if site UI differs.");
        }
    }

    public void applyOneStopFilterAndPrintCount() {
        try {
            // try clicking a one-stop filter if present
            List<WebElement> filters = driver.findElements(oneStopFilter);
            if(filters.size() > 0) {
                filters.get(0).click();
                Thread.sleep(2000);
            }
            List<WebElement> flights = driver.findElements(flightCards);
            System.out.println("\n🔎 Flights after applying one-stop filter: " + flights.size());
        } catch (Exception e) {
            System.out.println("⚠️ Could not apply one-stop filter or count flights: " + e.getMessage());
        }
    }
}
