# Infrrd Travel Automation Assignment - Abhishek Gowda

**Author:** Abhishek Gowda  
**Email:** abhishekgowda2911@gmail.com

## Overview
This project automates flight search on MakeMyTrip using Java, Selenium WebDriver, TestNG and Maven following Page Object Model (POM).

## How to run
1. Install Java 11+ and Maven.
2. In project root, run:
```
mvn clean test
```
This will run the TestNG suite and execute the flight search test.

## What the test does
- Navigate to https://www.makemytrip.com
- Go to Flights section
- Enter source (Bangalore) and destination (Delhi)
- Select a date in the next month
- Click Search
- Print the cheapest and second cheapest flight details to console
- Open a new browser tab and navigate to Google
- Extra scenario: Apply one-stop filter (if available) and print the filtered count

## Notes for interview
- I can explain any class and method in the project.
- Ready to modify locators or flow if the site's structure changes.
